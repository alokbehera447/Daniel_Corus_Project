var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/upload/route.js")
R.c("server/chunks/fd557_next_9ec7cd87._.js")
R.c("server/chunks/fd557_xlsx_xlsx_mjs_20efbf22._.js")
R.c("server/chunks/[root-of-the-server]__5847cf83._.js")
R.c("server/chunks/cdca0_Frontend__next-internal_server_app_api_upload_route_actions_fea9f349.js")
R.m("[project]/daniel-corus/Frontend/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/daniel-corus/Frontend/app/api/upload/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/daniel-corus/Frontend/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/daniel-corus/Frontend/app/api/upload/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
