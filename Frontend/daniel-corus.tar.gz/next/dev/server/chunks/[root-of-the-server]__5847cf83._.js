module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/daniel-corus/Frontend/app/api/upload/route.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/daniel-corus/Frontend/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$xlsx$2f$xlsx$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/daniel-corus/Frontend/node_modules/xlsx/xlsx.mjs [app-route] (ecmascript)");
;
;
async function POST(request) {
    try {
        const formData = await request.formData();
        const file = formData.get('file');
        if (!file) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'No file uploaded'
            }, {
                status: 400
            });
        }
        // Convert file to buffer
        const buffer = await file.arrayBuffer();
        // Parse Excel file
        const workbook = __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$xlsx$2f$xlsx$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["read"](buffer, {
            type: 'buffer'
        });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        // Get all data as array of arrays to see the actual structure
        const rawData = __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$xlsx$2f$xlsx$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["utils"].sheet_to_json(worksheet, {
            header: 1,
            defval: null,
            raw: false
        });
        console.log('Complete raw data structure:');
        rawData.slice(0, 5).forEach((row, i)=>{
            console.log(`Row ${i}:`, row);
        });
        if (rawData.length < 2) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Excel file has no data rows'
            }, {
                status: 400
            });
        }
        // Expected headers based on your Excel structure
        const expectedHeaders = [
            'MARK',
            'A(W1)',
            'B(W2)',
            'C(angle)',
            'D(length)',
            'Thickness',
            'α',
            'Volume',
            'AD',
            'UW-(Kg)',
            'Nos',
            'TOT V',
            'TOT KG'
        ];
        // Find the header row (first row with 'MARK')
        let headerRowIndex = 0;
        for(let i = 0; i < rawData.length; i++){
            if (rawData[i] && rawData[i][0] === 'MARK') {
                headerRowIndex = i;
                break;
            }
        }
        console.log('Header row found at index:', headerRowIndex);
        console.log('Header row:', rawData[headerRowIndex]);
        // Process data rows
        const processedData = rawData.slice(headerRowIndex + 1).filter((row)=>row && row[0] && row[0] !== 'MARK') // Remove empty rows and header
        .map((row)=>{
            return {
                'MARK': row[0],
                'A(W1)': row[1],
                'B(W2)': row[2],
                'C(angle)': row[3],
                'D(length)': row[4],
                'Thickness': row[5],
                'α': row[6],
                'Volume': row[7],
                'AD': row[8],
                'UW-(Kg)': row[9],
                'Nos': row[10],
                'TOT V': row[11],
                'TOT KG': row[12]
            };
        }).filter((row)=>row.MARK); // Remove rows without MARK
        console.log('Successfully processed data (first 3 rows):', processedData.slice(0, 3));
        return __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            data: processedData,
            totalRows: processedData.length,
            headers: expectedHeaders
        });
    } catch (error) {
        console.error('Error processing file:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            error: 'Error processing file: ' + error.message
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__5847cf83._.js.map