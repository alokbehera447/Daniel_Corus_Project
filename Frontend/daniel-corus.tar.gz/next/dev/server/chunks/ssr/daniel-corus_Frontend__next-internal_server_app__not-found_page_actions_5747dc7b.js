module.exports = [
"[project]/daniel-corus/Frontend/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=daniel-corus_Frontend__next-internal_server_app__not-found_page_actions_5747dc7b.js.map