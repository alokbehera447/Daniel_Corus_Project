module.exports = [
"[project]/daniel-corus/Frontend/.next-internal/server/app/visualization/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=cdca0_Frontend__next-internal_server_app_visualization_page_actions_6a949d74.js.map