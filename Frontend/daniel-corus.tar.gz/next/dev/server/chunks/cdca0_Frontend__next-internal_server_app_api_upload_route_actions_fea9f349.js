module.exports = [
"[project]/daniel-corus/Frontend/.next-internal/server/app/api/upload/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=cdca0_Frontend__next-internal_server_app_api_upload_route_actions_fea9f349.js.map