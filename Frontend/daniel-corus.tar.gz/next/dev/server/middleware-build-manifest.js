globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/fd557_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_c7bce699._.js",
    "static/chunks/fd557_next_dist_compiled_react-dom_ab31427f._.js",
    "static/chunks/fd557_next_dist_compiled_react-server-dom-turbopack_b7c5733d._.js",
    "static/chunks/fd557_next_dist_compiled_next-devtools_index_58106f7c.js",
    "static/chunks/fd557_next_dist_compiled_de8bc61b._.js",
    "static/chunks/fd557_next_dist_client_5f235470._.js",
    "static/chunks/fd557_next_dist_286c1b77._.js",
    "static/chunks/fd557_@swc_helpers_cjs_e199b1c5._.js",
    "static/chunks/daniel-corus_Frontend_a0ff3932._.js",
    "static/chunks/turbopack-daniel-corus_Frontend_14b4106a._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];