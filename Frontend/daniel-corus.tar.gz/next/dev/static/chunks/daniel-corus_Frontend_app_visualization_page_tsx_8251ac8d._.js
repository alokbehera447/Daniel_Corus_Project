(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/daniel-corus_Frontend_cc6de8c0._.js",
  "static/chunks/fd557_next_5db29e35._.js"
],
    source: "dynamic"
});
