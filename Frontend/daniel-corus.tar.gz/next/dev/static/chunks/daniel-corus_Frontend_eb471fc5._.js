(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/daniel-corus/Frontend/lib/config.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// lib/config.js
// export const API_URL = process.env.NEXT_PUBLIC_API_URL || "https://danieli-corus.diracai.com";
__turbopack_context__.s([
    "API_URL",
    ()=>API_URL
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/daniel-corus/Frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/daniel-corus/Frontend/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/daniel-corus/Frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/daniel-corus/Frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$lib$2f$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/daniel-corus/Frontend/lib/config.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function Home() {
    _s();
    // ==========================
    // AUTHENTICATION STATE
    // ==========================
    const [isLoggedIn, setIsLoggedIn] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showLogin, setShowLogin] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [username, setUsername] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [password, setPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [loginError, setLoginError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [userInitial, setUserInitial] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [accessToken, setAccessToken] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [refreshToken, setRefreshToken] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    // ==========================
    // EXISTING STATE MANAGEMENT
    // ==========================
    const [blockData, setBlockData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedBlocks, setSelectedBlocks] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isDropdownOpen, setIsDropdownOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [searchTerm, setSearchTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const dropdownRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const fileInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // PARENT BLOCK TYPES - MULTI-SELECT
    const parentBlocks = [
        "500×500×2000",
        "800×400×2000"
    ];
    const [selectedParents, setSelectedParents] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([
        "500×500×2000"
    ]);
    // RUN LOGIC
    const [running, setRunning] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [approaches, setApproaches] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loginLoading, setLoginLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isMobile, setIsMobile] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isUserDropdownOpen, setIsUserDropdownOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // ==========================
    // JWT AUTHENTICATION FUNCTIONS
    // ==========================
    const handleLogin = async (e)=>{
        e.preventDefault();
        setLoginError("");
        setLoginLoading(true);
        // Basic validation
        if (!username.trim() || !password.trim()) {
            setLoginError("Please enter both username and password");
            setLoginLoading(false);
            return;
        }
        try {
            // Make API call to Django JWT endpoint
            const response = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$lib$2f$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_URL"]}/auth/login/`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    username: username.trim(),
                    password: password.trim()
                })
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.detail || `Login failed: ${response.statusText}`);
            }
            const data = await response.json();
            // Store tokens
            setAccessToken(data.access);
            setRefreshToken(data.refresh);
            // Update authentication state
            setIsLoggedIn(true);
            setShowLogin(false);
            setUserInitial(username.charAt(0).toUpperCase());
            // Store authentication state
            localStorage.setItem("isLoggedIn", "true");
            localStorage.setItem("userInitial", username.charAt(0).toUpperCase());
            localStorage.setItem("accessToken", data.access);
            localStorage.setItem("refreshToken", data.refresh);
            localStorage.setItem("username", username.trim());
            setLoginError("");
        } catch (error) {
            console.error("Login error:", error);
            setLoginError(error.message || "Invalid credentials. Please try again.");
        } finally{
            setLoginLoading(false);
        }
    };
    const refreshAccessToken = async ()=>{
        try {
            const refresh = localStorage.getItem("refreshToken");
            if (!refresh) {
                throw new Error("No refresh token available");
            }
            const response = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$lib$2f$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_URL"]}/auth/refresh/`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    refresh: refresh
                })
            });
            if (!response.ok) {
                throw new Error("Token refresh failed");
            }
            const data = await response.json();
            const newAccessToken = data.access;
            // Update tokens
            setAccessToken(newAccessToken);
            localStorage.setItem("accessToken", newAccessToken);
            return newAccessToken;
        } catch (error) {
            console.error("Token refresh error:", error);
            handleLogout();
            return null;
        }
    };
    const handleLogout = ()=>{
        setIsLoggedIn(false);
        setShowLogin(true);
        setUsername("");
        setPassword("");
        setUserInitial("");
        setAccessToken("");
        setRefreshToken("");
        setIsUserDropdownOpen(false);
        // Clear all auth data from localStorage
        localStorage.removeItem("isLoggedIn");
        localStorage.removeItem("userInitial");
        localStorage.removeItem("accessToken");
        localStorage.removeItem("refreshToken");
        localStorage.removeItem("username");
    };
    // Check for existing login on component mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            const loggedIn = localStorage.getItem("isLoggedIn");
            const initial = localStorage.getItem("userInitial");
            const storedAccessToken = localStorage.getItem("accessToken");
            const storedRefreshToken = localStorage.getItem("refreshToken");
            const storedUsername = localStorage.getItem("username");
            if (loggedIn === "true" && initial && storedAccessToken && storedRefreshToken && storedUsername) {
                setIsLoggedIn(true);
                setShowLogin(false);
                setUserInitial(initial);
                setAccessToken(storedAccessToken);
                setRefreshToken(storedRefreshToken);
                setUsername(storedUsername);
            }
        }
    }["Home.useEffect"], []);
    // ==========================
    // AUTHENTICATED API REQUEST FUNCTION
    // ==========================
    // ==========================
    // AUTHENTICATED API REQUEST FUNCTION
    // ==========================
    const makeAuthenticatedRequest = async (url, options = {})=>{
        let token = accessToken;
        console.log("Making authenticated request with token:", token ? "Present" : "Missing");
        if (!token) {
            console.error("No access token available");
            const storedToken = localStorage.getItem("accessToken");
            if (storedToken) {
                token = storedToken;
                setAccessToken(storedToken);
            } else {
                throw new Error("No authentication token available");
            }
        }
        // Prepare headers
        const headers = new Headers(options.headers);
        // Add authorization header
        headers.set("Authorization", `Bearer ${token}`);
        // CRITICAL: For FormData, DELETE Content-Type to let browser set it with boundary
        if (options.body instanceof FormData) {
            headers.delete("Content-Type");
            console.log("FormData detected - Content-Type header removed");
        } else {
            // Only set Content-Type for non-FormData requests
            if (!headers.has("Content-Type")) {
                headers.set("Content-Type", "application/json");
            }
        }
        // Build full URL
        let fullUrl = url;
        if (url.startsWith("/")) {
            fullUrl = `${__TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$lib$2f$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_URL"]}${url}`;
        }
        console.log(`Request URL: ${fullUrl}`);
        console.log(`Request method: ${options.method || "GET"}`);
        console.log(`Body type:`, options.body instanceof FormData ? "FormData" : typeof options.body);
        console.log(`Headers:`, Object.fromEntries(headers.entries()));
        try {
            const response = await fetch(fullUrl, {
                ...options,
                headers
            });
            console.log(`Response status: ${response.status}`);
            // Log response for debugging
            if (!response.ok) {
                const responseText = await response.text();
                console.error(`Response error:`, responseText);
                // Try to parse as JSON
                try {
                    const errorData = JSON.parse(responseText);
                    console.error(`Parsed error:`, errorData);
                } catch (e) {
                    console.error(`Raw error text:`, responseText);
                }
            }
            // If token expired, try to refresh it
            if (response.status === 401) {
                console.log("Token expired, attempting refresh...");
                const newToken = await refreshAccessToken();
                if (newToken) {
                    headers.set("Authorization", `Bearer ${newToken}`);
                    // For FormData, make sure Content-Type is still deleted after refresh
                    if (options.body instanceof FormData) {
                        headers.delete("Content-Type");
                    }
                    return await fetch(fullUrl, {
                        ...options,
                        headers
                    });
                } else {
                    handleLogout();
                    throw new Error("Session expired. Please login again.");
                }
            }
            return response;
        } catch (error) {
            console.error("API request error:", error);
            throw error;
        }
    };
    // ==========================
    // UPDATED FILE IMPORT HANDLER WITH AUTH
    // ==========================
    const handleFileUpload = async (event)=>{
        const file = event.target.files?.[0];
        if (!file) return;
        if (!file.name.match(/\.(xlsx|xls|csv)$/)) {
            setError("Please upload a valid Excel file (.xlsx, .xls, .csv)");
            return;
        }
        const formData = new FormData();
        formData.append("file", file);
        try {
            setError(null);
            // Use authenticated request for upload
            const response = await makeAuthenticatedRequest(`/api/upload/`, {
                method: "POST",
                body: formData
            });
            if (!response.ok) {
                if (response.status === 401) {
                    throw new Error("Authentication required. Please login again.");
                }
                throw new Error(`Upload failed: ${response.statusText}`);
            }
            const result = await response.json();
            if (result.success && result.data) {
                setBlockData(result.data);
                setSelectedBlocks([]);
                setIsDropdownOpen(false);
                setSearchTerm("");
                if (fileInputRef.current) {
                    fileInputRef.current.value = "";
                }
            } else {
                setError(result.error || "Failed to process Excel file");
            }
        } catch (error) {
            console.error("Error uploading file:", error);
            setError(error.message || "Error uploading file. Please try again.");
        }
    };
    // ==========================
    // EXISTING HELPER FUNCTIONS
    // ==========================
    // Get block identifier - always returns a string
    const getBlockIdentifier = (block)=>{
        try {
            const identifier = block?.MARK || block?.mark || `Block-${blockData.indexOf(block) + 1}`;
            return String(identifier || "");
        } catch (error) {
            console.error("Error getting block identifier:", error, block);
            return `Block-${blockData.indexOf(block) + 1}`;
        }
    };
    // Get block value with exact field names
    const getBlockValue = (block, field)=>{
        if (!block) return "N/A";
        const value = block[field];
        return value !== undefined && value !== null && value !== "" ? value : "N/A";
    };
    // Calculate selectAll status based on selectedBlocks
    const selectAll = selectedBlocks.length === blockData.length && blockData.length > 0;
    // Filter blocks based on search term
    const filteredBlocks = blockData.filter((block)=>{
        try {
            const blockId = getBlockIdentifier(block);
            const searchText = searchTerm.toLowerCase();
            return String(blockId).toLowerCase().includes(searchText);
        } catch (error) {
            console.error("Error in block filtering:", error, block);
            return false;
        }
    });
    // Close dropdown when clicking outside
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            const handleClickOutside = {
                "Home.useEffect.handleClickOutside": (event)=>{
                    const target = event.target;
                    // Only close on click outside for mobile devices
                    if (isMobile && !target.closest(".user-profile-dropdown")) {
                        setIsUserDropdownOpen(false);
                    }
                }
            }["Home.useEffect.handleClickOutside"];
            document.addEventListener("mousedown", handleClickOutside);
            return ({
                "Home.useEffect": ()=>document.removeEventListener("mousedown", handleClickOutside)
            })["Home.useEffect"];
        }
    }["Home.useEffect"], [
        isMobile
    ]);
    // Add device detection
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            const checkDevice = {
                "Home.useEffect.checkDevice": ()=>{
                    setIsMobile(window.innerWidth < 768);
                }
            }["Home.useEffect.checkDevice"];
            // Check initially
            checkDevice();
            // Add resize listener
            window.addEventListener("resize", checkDevice);
            return ({
                "Home.useEffect": ()=>window.removeEventListener("resize", checkDevice)
            })["Home.useEffect"];
        }
    }["Home.useEffect"], []);
    // Trigger file input click
    const triggerFileInput = ()=>{
        fileInputRef.current?.click();
    };
    // ==========================
    // EXISTING BLOCK SELECTION HANDLERS
    // ==========================
    const toggleBlock = (mark, e)=>{
        if (e) {
            e.stopPropagation();
        }
        setSelectedBlocks((prev)=>prev.includes(mark) ? prev.filter((x)=>x !== mark) : [
                ...prev,
                mark
            ]);
    };
    const handleSelectAll = ()=>{
        if (!selectAll) {
            setSelectedBlocks(blockData.map((b)=>getBlockIdentifier(b)));
        } else {
            setSelectedBlocks([]);
        }
    };
    const removeSelectedBlock = (mark, e)=>{
        e.stopPropagation();
        setSelectedBlocks((prev)=>prev.filter((m)=>m !== mark));
    };
    // ==========================
    // PARENT BLOCK SELECTION HANDLERS
    // ==========================
    const toggleParentBlock = (parent)=>{
        setSelectedParents((prev)=>prev.includes(parent) ? prev.filter((p)=>p !== parent) : [
                ...prev,
                parent
            ]);
    };
    const handleSelectAllParents = ()=>{
        if (selectedParents.length === parentBlocks.length) {
            setSelectedParents([]);
        } else {
            setSelectedParents([
                ...parentBlocks
            ]);
        }
    };
    // ==========================
    // UPDATED RUN BUTTON LOGIC WITH MULTI-PARENT SUPPORT
    // ==========================
    const onRun = async ()=>{
        if (blockData.length === 0) {
            setError("Please import an Excel file first.");
            return;
        }
        if (selectedBlocks.length === 0) {
            setError("Please select at least one block.");
            return;
        }
        if (selectedParents.length === 0) {
            setError("Please select at least one parent block.");
            return;
        }
        setError(null);
        setRunning(true);
        setApproaches([]);
        try {
            // Get selected block objects
            const selectedBlockObjects = blockData.filter((block)=>selectedBlocks.includes(getBlockIdentifier(block)));
            // Use the first selected parent for backward compatibility
            // Later you can modify this to handle multiple parents
            const [width, height, length] = selectedParents[0].split("×").map((dim)=>parseInt(dim.trim(), 10));
            // Transform blocks to API format
            const parts = selectedBlockObjects.map((block)=>({
                    name: getBlockIdentifier(block),
                    W1: parseFloat(getBlockValue(block, "A(W1)")) || 0,
                    W2: parseFloat(getBlockValue(block, "B(W2)")) || 0,
                    D: parseFloat(getBlockValue(block, "D(length)")) || 0,
                    thickness: parseFloat(getBlockValue(block, "Thickness")) || 0,
                    alpha: parseFloat(getBlockValue(block, "α")) || 0
                }));
            // Prepare request payload
            const payload = {
                stock_dimensions: {
                    length: length,
                    width: width,
                    height: height
                },
                parts: parts,
                config_params: {
                    saw_kerf: 0.0,
                    merging_plane_orders: [
                        "XY-X"
                    ]
                },
                top_n: 3
            };
            console.log("Sending optimization request:", payload);
            console.log("Selected parent blocks:", selectedParents);
            // Call the optimization API
            const response = await makeAuthenticatedRequest(`/api/configurations/top3/`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(payload)
            });
            if (!response.ok) {
                throw new Error(`API Error: ${response.statusText}`);
            }
            const result = await response.json();
            console.log("Received optimization response:", result);
            // Transform API response to match UI format
            const transformedApproaches = result.configurations?.map((config, idx)=>({
                    title: `Approach ${config.rank}`,
                    desc: config.description || `Optimized cutting plan using ${selectedParents.length} stock type(s)`,
                    efficiency: `${config.efficiency?.toFixed(1)}%`,
                    waste: `${config.waste?.toFixed(1)}%`,
                    color: idx === 0 ? "from-green-500 to-emerald-600" : idx === 1 ? "from-blue-500 to-cyan-600" : "from-purple-500 to-indigo-600",
                    // Store additional data for potential future use
                    totalParts: config.total_parts,
                    partsBreakdown: config.parts_breakdown,
                    primaryPart: config.primary_part,
                    mergingPlaneOrder: config.merging_plane_order,
                    visualizationFile: config.visualization_file,
                    stockTypesUsed: selectedParents
                })) || [];
            setApproaches(transformedApproaches);
        } catch (error) {
            console.error("Error running optimization:", error);
            setError(error instanceof Error ? error.message : "Failed to run optimization. Please try again.");
        } finally{
            setRunning(false);
        }
    };
    // Selected blocks display text
    const selectedBlocksText = selectedBlocks.length === 0 ? "No blocks selected" : `${selectedBlocks.length} block${selectedBlocks.length > 1 ? "s" : ""} selected`;
    // ==========================
    // RENDER MAIN INTERFACE
    // ==========================
    const renderMainInterface = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
            className: `min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6 ${showLogin ? "blur-sm" : ""}`,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-6xl mx-auto",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between items-center mb-10",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: "/danieli_logo.svg",
                                        alt: "Danieli Corus Logo",
                                        className: "h-10 w-auto"
                                    }, void 0, false, {
                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                        lineNumber: 604,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                        className: "text-3xl font-bold text-black tracking-tight",
                                        children: [
                                            "DANIELI ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-light",
                                                children: "CORUS"
                                            }, void 0, false, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 610,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                        lineNumber: 609,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                lineNumber: 603,
                                columnNumber: 11
                            }, this),
                            isLoggedIn && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-4",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative group user-profile-dropdown",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-lg cursor-pointer shadow-lg",
                                            onClick: isMobile ? ()=>setIsUserDropdownOpen(!isUserDropdownOpen) : undefined,
                                            children: userInitial
                                        }, void 0, false, {
                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                            lineNumber: 618,
                                            columnNumber: 17
                                        }, this),
                                        !isMobile && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "absolute right-0 top-full mt-2 w-48 bg-white/95 backdrop-blur-lg rounded-xl shadow-2xl border border-white/20 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "p-3 border-b border-gray-100",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-sm text-gray-600 font-medium",
                                                            children: "Signed in as"
                                                        }, void 0, false, {
                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                            lineNumber: 632,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "font-semibold text-gray-800 truncate",
                                                            children: username
                                                        }, void 0, false, {
                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                            lineNumber: 635,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                    lineNumber: 631,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: handleLogout,
                                                    className: "w-full px-4 py-3 text-left text-gray-700 hover:bg-red-50 hover:text-red-600 rounded-xl transition-colors font-medium flex items-center gap-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                            className: "w-4 h-4",
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            viewBox: "0 0 24 24",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                strokeLinecap: "round",
                                                                strokeLinejoin: "round",
                                                                strokeWidth: 2,
                                                                d: "M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
                                                            }, void 0, false, {
                                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                lineNumber: 649,
                                                                columnNumber: 25
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                            lineNumber: 643,
                                                            columnNumber: 23
                                                        }, this),
                                                        "Logout"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                    lineNumber: 639,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                            lineNumber: 630,
                                            columnNumber: 19
                                        }, this),
                                        isMobile && isUserDropdownOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "absolute right-0 top-full mt-2 w-48 bg-white/95 backdrop-blur-lg rounded-xl shadow-2xl border border-white/20 z-50",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "p-3 border-b border-gray-100",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-sm text-gray-600 font-medium",
                                                            children: "Signed in as"
                                                        }, void 0, false, {
                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                            lineNumber: 664,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "font-semibold text-gray-800 truncate",
                                                            children: username
                                                        }, void 0, false, {
                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                            lineNumber: 667,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                    lineNumber: 663,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: handleLogout,
                                                    className: "w-full px-4 py-3 text-left text-gray-700 hover:bg-red-50 hover:text-red-600 rounded-xl transition-colors font-medium flex items-center gap-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                            className: "w-4 h-4",
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            viewBox: "0 0 24 24",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                strokeLinecap: "round",
                                                                strokeLinejoin: "round",
                                                                strokeWidth: 2,
                                                                d: "M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
                                                            }, void 0, false, {
                                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                lineNumber: 681,
                                                                columnNumber: 25
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                            lineNumber: 675,
                                                            columnNumber: 23
                                                        }, this),
                                                        "Logout"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                    lineNumber: 671,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                            lineNumber: 662,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                    lineNumber: 617,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                lineNumber: 616,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                        lineNumber: 601,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-2xl border border-white/20 mb-10",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-3 mb-8",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-2 h-8 bg-gradient-to-b from-blue-500 to-purple-600 rounded-full"
                                    }, void 0, false, {
                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                        lineNumber: 700,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-2xl font-bold text-gray-800",
                                        children: "Import Requirements"
                                    }, void 0, false, {
                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                        lineNumber: 701,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                lineNumber: 699,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-8",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "font-semibold text-lg mb-4 text-gray-700 flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "w-2 h-2 bg-blue-500 rounded-full"
                                            }, void 0, false, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 709,
                                                columnNumber: 15
                                            }, this),
                                            "Import Blocks from Excel"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                        lineNumber: 708,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "file",
                                        ref: fileInputRef,
                                        onChange: handleFileUpload,
                                        accept: ".xlsx, .xls, .csv",
                                        className: "hidden"
                                    }, void 0, false, {
                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                        lineNumber: 713,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: triggerFileInput,
                                        className: "w-full p-6 border-2 border-dashed border-gray-300 bg-white/50 rounded-xl shadow-sm hover:border-blue-300 hover:bg-blue-50/50 transition-all duration-300 backdrop-blur-sm text-center group",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex flex-col items-center gap-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        className: "w-6 h-6 text-white",
                                                        fill: "none",
                                                        stroke: "currentColor",
                                                        viewBox: "0 0 24 24",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round",
                                                            strokeWidth: 2,
                                                            d: "M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                                                        }, void 0, false, {
                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                            lineNumber: 733,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                        lineNumber: 727,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                    lineNumber: 726,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-gray-700 font-semibold text-lg",
                                                            children: blockData.length > 0 ? `✅ Imported ${blockData.length} blocks` : "Click to import Excel file"
                                                        }, void 0, false, {
                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                            lineNumber: 742,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-sm text-gray-500 mt-1",
                                                            children: "Supports .xlsx, .xls, .csv files with block data"
                                                        }, void 0, false, {
                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                            lineNumber: 747,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                    lineNumber: 741,
                                                    columnNumber: 17
                                                }, this),
                                                blockData.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-blue-600 text-sm font-medium",
                                                    children: "Click to re-import"
                                                }, void 0, false, {
                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                    lineNumber: 752,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                            lineNumber: 725,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                        lineNumber: 721,
                                        columnNumber: 13
                                    }, this),
                                    blockData.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-4 p-4 bg-blue-50/50 rounded-lg border border-blue-200/50",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex justify-between items-start mb-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                        className: "font-semibold text-blue-800 mb-2 flex items-center gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                className: "w-4 h-4",
                                                                fill: "currentColor",
                                                                viewBox: "0 0 20 20",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    fillRule: "evenodd",
                                                                    d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z",
                                                                    clipRule: "evenodd"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                    lineNumber: 770,
                                                                    columnNumber: 23
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                lineNumber: 765,
                                                                columnNumber: 21
                                                            }, this),
                                                            "Expected Excel Format:"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                        lineNumber: 764,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                        href: "/Triel_3_rows.xlsx",
                                                        download: "Triel_3_rows.xlsx",
                                                        className: "flex items-center gap-2 px-3 py-2 bg-gradient-to-r from-green-500 to-emerald-600 text-white text-sm font-semibold rounded-lg shadow hover:from-green-600 hover:to-emerald-700 transition-all duration-300 hover:scale-105 active:scale-95",
                                                        onClick: (e)=>{
                                                            // Optional: Add tracking or analytics
                                                            console.log("Sample Excel file downloaded");
                                                        },
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                className: "w-4 h-4",
                                                                fill: "none",
                                                                stroke: "currentColor",
                                                                viewBox: "0 0 24 24",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round",
                                                                    strokeWidth: 2,
                                                                    d: "M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                    lineNumber: 795,
                                                                    columnNumber: 23
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                lineNumber: 789,
                                                                columnNumber: 21
                                                            }, this),
                                                            "Download Sample"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                        lineNumber: 780,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 763,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                className: "text-sm text-blue-700 list-disc list-inside space-y-1 mb-3",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                        children: "Columns: MARK, A(W1), B(W2), C(angle), D(length), Thickness, α, Volume, AD, UW-(Kg), Nos, TOT V, TOT KG"
                                                    }, void 0, false, {
                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                        lineNumber: 807,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                        children: "First row should contain headers"
                                                    }, void 0, false, {
                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                        lineNumber: 811,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                        children: "Supported formats: Excel (.xlsx, .xls) or CSV"
                                                    }, void 0, false, {
                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                        lineNumber: 812,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 806,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xs text-blue-600 italic mt-2",
                                                children: "Download the sample file above to see the required format"
                                            }, void 0, false, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 815,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                        lineNumber: 762,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                lineNumber: 707,
                                columnNumber: 11
                            }, this),
                            blockData.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-8",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "font-semibold text-lg mb-4 text-gray-700 flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "w-2 h-2 bg-green-500 rounded-full"
                                            }, void 0, false, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 826,
                                                columnNumber: 17
                                            }, this),
                                            "Select Blocks"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                        lineNumber: 825,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        ref: dropdownRef,
                                        className: "relative cursor-pointer",
                                        onClick: ()=>setIsDropdownOpen(!isDropdownOpen),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "border-2 border-gray-200/80 bg-white/50 p-4 rounded-xl shadow-sm hover:border-blue-300/50 transition-all duration-300 backdrop-blur-sm min-h-[60px]",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex justify-between items-center",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex flex-wrap gap-2 flex-1",
                                                            children: selectedBlocks.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-gray-400 font-medium",
                                                                children: selectedBlocksText
                                                            }, void 0, false, {
                                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                lineNumber: 839,
                                                                columnNumber: 25
                                                            }, this) : selectedBlocks.map((mark)=>{
                                                                const block = blockData.find((b)=>getBlockIdentifier(b) === mark);
                                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center gap-2 bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium group hover:bg-blue-200 transition-colors",
                                                                    onClick: (e)=>e.stopPropagation(),
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            children: mark
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                            lineNumber: 853,
                                                                            columnNumber: 31
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-xs text-blue-600",
                                                                            children: [
                                                                                "(",
                                                                                getBlockValue(block, "Nos"),
                                                                                " units)"
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                            lineNumber: 854,
                                                                            columnNumber: 31
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            onClick: (e)=>removeSelectedBlock(mark, e),
                                                                            className: "w-4 h-4 rounded-full bg-blue-500 text-white flex items-center justify-center text-xs hover:bg-blue-600 transition-colors",
                                                                            children: "×"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                            lineNumber: 857,
                                                                            columnNumber: 31
                                                                        }, this)
                                                                    ]
                                                                }, mark, true, {
                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                    lineNumber: 848,
                                                                    columnNumber: 29
                                                                }, this);
                                                            })
                                                        }, void 0, false, {
                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                            lineNumber: 837,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                            className: `w-5 h-5 text-gray-400 transition-transform duration-300 flex-shrink-0 ${isDropdownOpen ? "rotate-180" : ""}`,
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            viewBox: "0 0 24 24",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                strokeLinecap: "round",
                                                                strokeLinejoin: "round",
                                                                strokeWidth: 2,
                                                                d: "M19 9l-7 7-7-7"
                                                            }, void 0, false, {
                                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                lineNumber: 876,
                                                                columnNumber: 23
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                            lineNumber: 868,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                    lineNumber: 836,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 835,
                                                columnNumber: 17
                                            }, this),
                                            isDropdownOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "absolute top-full left-0 right-0 mt-2 bg-white/95 backdrop-blur-lg border border-gray-200/80 rounded-xl shadow-2xl z-50 max-h-96 overflow-y-auto",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "p-4 border-b border-gray-100/50 bg-white",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "relative",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                    className: "w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500",
                                                                    fill: "none",
                                                                    stroke: "currentColor",
                                                                    viewBox: "0 0 24 24",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                        strokeLinecap: "round",
                                                                        strokeLinejoin: "round",
                                                                        strokeWidth: 2,
                                                                        d: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                        lineNumber: 898,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                    lineNumber: 892,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "text",
                                                                    placeholder: "Search blocks (e.g., G14, G15...)",
                                                                    className: "w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white text-gray-900 placeholder-gray-500",
                                                                    value: searchTerm,
                                                                    onChange: (e)=>setSearchTerm(e.target.value),
                                                                    onClick: (e)=>e.stopPropagation()
                                                                }, void 0, false, {
                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                    lineNumber: 905,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                            lineNumber: 891,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                        lineNumber: 890,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-3 p-3 border-b border-gray-100/50 hover:bg-blue-50/50 transition-colors cursor-pointer",
                                                        onClick: handleSelectAll,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: `w-5 h-5 border-2 rounded-md flex items-center justify-center transition-all duration-200 ${selectAll ? "bg-blue-500 border-blue-500" : "border-gray-300"}`,
                                                                children: selectAll && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                    className: "w-3 h-3 text-white",
                                                                    fill: "currentColor",
                                                                    viewBox: "0 0 20 20",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                        fillRule: "evenodd",
                                                                        d: "M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z",
                                                                        clipRule: "evenodd"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                        lineNumber: 933,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                    lineNumber: 928,
                                                                    columnNumber: 27
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                lineNumber: 920,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "font-medium text-gray-700",
                                                                children: selectAll ? "Deselect All Blocks" : "Select All Blocks"
                                                            }, void 0, false, {
                                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                lineNumber: 941,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                        lineNumber: 916,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "max-h-80 overflow-y-auto",
                                                        children: filteredBlocks.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "p-4 text-center text-gray-500",
                                                            children: [
                                                                'No blocks found matching "',
                                                                searchTerm,
                                                                '"'
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                            lineNumber: 951,
                                                            columnNumber: 25
                                                        }, this) : filteredBlocks.map((block, index)=>{
                                                            const blockId = getBlockIdentifier(block);
                                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-center gap-3 p-3 hover:bg-gray-50/80 transition-colors cursor-pointer border-b border-gray-100/30 last:border-b-0",
                                                                onClick: (e)=>toggleBlock(blockId, e),
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: `w-5 h-5 border-2 rounded-md flex items-center justify-center transition-all duration-200 flex-shrink-0 ${selectedBlocks.includes(blockId) ? "bg-blue-500 border-blue-500" : "border-gray-300"}`,
                                                                        children: selectedBlocks.includes(blockId) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                            className: "w-3 h-3 text-white",
                                                                            fill: "currentColor",
                                                                            viewBox: "0 0 20 20",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                                fillRule: "evenodd",
                                                                                d: "M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z",
                                                                                clipRule: "evenodd"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                lineNumber: 976,
                                                                                columnNumber: 37
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                            lineNumber: 971,
                                                                            columnNumber: 35
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                        lineNumber: 963,
                                                                        columnNumber: 31
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "flex-1 min-w-0",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex items-center justify-between",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "flex items-center gap-3 flex-1 min-w-0",
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                            className: "font-bold text-gray-800 text-sm whitespace-nowrap flex-shrink-0",
                                                                                            children: blockId
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                            lineNumber: 989,
                                                                                            columnNumber: 37
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                            className: "flex items-center gap-4 text-xs text-gray-600 flex-1 overflow-x-auto scrollbar-hide",
                                                                                            children: [
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                    className: "whitespace-nowrap",
                                                                                                    children: [
                                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                                                            children: "A:"
                                                                                                        }, void 0, false, {
                                                                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                                            lineNumber: 994,
                                                                                                            columnNumber: 41
                                                                                                        }, this),
                                                                                                        " ",
                                                                                                        getBlockValue(block, "A(W1)")
                                                                                                    ]
                                                                                                }, void 0, true, {
                                                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                                    lineNumber: 993,
                                                                                                    columnNumber: 39
                                                                                                }, this),
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                    className: "whitespace-nowrap",
                                                                                                    children: [
                                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                                                            children: "B:"
                                                                                                        }, void 0, false, {
                                                                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                                            lineNumber: 998,
                                                                                                            columnNumber: 41
                                                                                                        }, this),
                                                                                                        " ",
                                                                                                        getBlockValue(block, "B(W2)")
                                                                                                    ]
                                                                                                }, void 0, true, {
                                                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                                    lineNumber: 997,
                                                                                                    columnNumber: 39
                                                                                                }, this),
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                    className: "whitespace-nowrap",
                                                                                                    children: [
                                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                                                            children: "C:"
                                                                                                        }, void 0, false, {
                                                                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                                            lineNumber: 1002,
                                                                                                            columnNumber: 41
                                                                                                        }, this),
                                                                                                        " ",
                                                                                                        getBlockValue(block, "C(angle)")
                                                                                                    ]
                                                                                                }, void 0, true, {
                                                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                                    lineNumber: 1001,
                                                                                                    columnNumber: 39
                                                                                                }, this),
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                    className: "whitespace-nowrap",
                                                                                                    children: [
                                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                                                            children: "D:"
                                                                                                        }, void 0, false, {
                                                                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                                            lineNumber: 1006,
                                                                                                            columnNumber: 41
                                                                                                        }, this),
                                                                                                        " ",
                                                                                                        getBlockValue(block, "D(length)")
                                                                                                    ]
                                                                                                }, void 0, true, {
                                                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                                    lineNumber: 1005,
                                                                                                    columnNumber: 39
                                                                                                }, this),
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                    className: "whitespace-nowrap",
                                                                                                    children: [
                                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                                                            children: "Thick:"
                                                                                                        }, void 0, false, {
                                                                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                                            lineNumber: 1010,
                                                                                                            columnNumber: 41
                                                                                                        }, this),
                                                                                                        " ",
                                                                                                        getBlockValue(block, "Thickness")
                                                                                                    ]
                                                                                                }, void 0, true, {
                                                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                                    lineNumber: 1009,
                                                                                                    columnNumber: 39
                                                                                                }, this),
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                    className: "whitespace-nowrap",
                                                                                                    children: [
                                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                                                            children: "α:"
                                                                                                        }, void 0, false, {
                                                                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                                            lineNumber: 1014,
                                                                                                            columnNumber: 41
                                                                                                        }, this),
                                                                                                        " ",
                                                                                                        getBlockValue(block, "α")
                                                                                                    ]
                                                                                                }, void 0, true, {
                                                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                                    lineNumber: 1013,
                                                                                                    columnNumber: 39
                                                                                                }, this),
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                    className: "whitespace-nowrap",
                                                                                                    children: [
                                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                                                            children: "Vol:"
                                                                                                        }, void 0, false, {
                                                                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                                            lineNumber: 1018,
                                                                                                            columnNumber: 41
                                                                                                        }, this),
                                                                                                        " ",
                                                                                                        getBlockValue(block, "Volume")
                                                                                                    ]
                                                                                                }, void 0, true, {
                                                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                                    lineNumber: 1017,
                                                                                                    columnNumber: 39
                                                                                                }, this),
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                    className: "whitespace-nowrap",
                                                                                                    children: [
                                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                                                            children: "TOT V:"
                                                                                                        }, void 0, false, {
                                                                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                                            lineNumber: 1022,
                                                                                                            columnNumber: 41
                                                                                                        }, this),
                                                                                                        " ",
                                                                                                        getBlockValue(block, "TOT V")
                                                                                                    ]
                                                                                                }, void 0, true, {
                                                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                                    lineNumber: 1021,
                                                                                                    columnNumber: 39
                                                                                                }, this),
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                    className: "whitespace-nowrap",
                                                                                                    children: [
                                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                                                            children: "TOT KG:"
                                                                                                        }, void 0, false, {
                                                                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                                            lineNumber: 1026,
                                                                                                            columnNumber: 41
                                                                                                        }, this),
                                                                                                        " ",
                                                                                                        getBlockValue(block, "TOT KG")
                                                                                                    ]
                                                                                                }, void 0, true, {
                                                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                                    lineNumber: 1025,
                                                                                                    columnNumber: 39
                                                                                                }, this)
                                                                                            ]
                                                                                        }, void 0, true, {
                                                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                            lineNumber: 992,
                                                                                            columnNumber: 37
                                                                                        }, this)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                    lineNumber: 988,
                                                                                    columnNumber: 35
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "flex gap-2 ml-3 flex-shrink-0",
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                            className: "bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs font-semibold whitespace-nowrap",
                                                                                            children: [
                                                                                                getBlockValue(block, "Nos"),
                                                                                                " units"
                                                                                            ]
                                                                                        }, void 0, true, {
                                                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                            lineNumber: 1032,
                                                                                            columnNumber: 37
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                            className: "bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs font-semibold whitespace-nowrap",
                                                                                            children: [
                                                                                                getBlockValue(block, "UW-(Kg)"),
                                                                                                " kg"
                                                                                            ]
                                                                                        }, void 0, true, {
                                                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                            lineNumber: 1035,
                                                                                            columnNumber: 37
                                                                                        }, this)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                    lineNumber: 1031,
                                                                                    columnNumber: 35
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                            lineNumber: 987,
                                                                            columnNumber: 33
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                        lineNumber: 986,
                                                                        columnNumber: 31
                                                                    }, this)
                                                                ]
                                                            }, blockId, true, {
                                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                lineNumber: 958,
                                                                columnNumber: 29
                                                            }, this);
                                                        })
                                                    }, void 0, false, {
                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                        lineNumber: 949,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 888,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                        lineNumber: 830,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                lineNumber: 824,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-8",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "font-semibold text-lg mb-4 text-gray-700 flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "w-2 h-2 bg-purple-500 rounded-full"
                                            }, void 0, false, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 1055,
                                                columnNumber: 15
                                            }, this),
                                            "Select Parent Blocks (Select one or both)"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                        lineNumber: 1054,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-3 p-3 border-2 border-gray-200/80 bg-white/50 rounded-xl shadow-sm hover:border-purple-300/50 transition-all duration-300 backdrop-blur-sm cursor-pointer",
                                                onClick: handleSelectAllParents,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: `w-5 h-5 border-2 rounded-md flex items-center justify-center transition-all duration-200 ${selectedParents.length === parentBlocks.length ? "bg-purple-500 border-purple-500" : "border-gray-300"}`,
                                                        children: selectedParents.length === parentBlocks.length && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                            className: "w-3 h-3 text-white",
                                                            fill: "currentColor",
                                                            viewBox: "0 0 20 20",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                fillRule: "evenodd",
                                                                d: "M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z",
                                                                clipRule: "evenodd"
                                                            }, void 0, false, {
                                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                lineNumber: 1078,
                                                                columnNumber: 23
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                            lineNumber: 1073,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                        lineNumber: 1065,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-medium text-gray-700",
                                                        children: selectedParents.length === parentBlocks.length ? "Deselect All Parent Blocks" : "Select All Parent Blocks"
                                                    }, void 0, false, {
                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                        lineNumber: 1086,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 1061,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                                                children: parentBlocks.map((parent)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: `p-4 border-2 rounded-xl shadow-sm transition-all duration-300 backdrop-blur-sm cursor-pointer ${selectedParents.includes(parent) ? "border-purple-500 bg-purple-50/50" : "border-gray-200/80 bg-white/50 hover:border-purple-300/50"}`,
                                                        onClick: ()=>toggleParentBlock(parent),
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center justify-between",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center gap-3",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: `w-5 h-5 border-2 rounded-md flex items-center justify-center transition-all duration-200 ${selectedParents.includes(parent) ? "bg-purple-500 border-purple-500" : "border-gray-300"}`,
                                                                            children: selectedParents.includes(parent) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                                className: "w-3 h-3 text-white",
                                                                                fill: "currentColor",
                                                                                viewBox: "0 0 20 20",
                                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                                    fillRule: "evenodd",
                                                                                    d: "M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z",
                                                                                    clipRule: "evenodd"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                    lineNumber: 1120,
                                                                                    columnNumber: 31
                                                                                }, this)
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                                lineNumber: 1115,
                                                                                columnNumber: 29
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                            lineNumber: 1107,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "font-medium text-gray-700",
                                                                            children: parent
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                            lineNumber: 1128,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                    lineNumber: 1106,
                                                                    columnNumber: 23
                                                                }, this),
                                                                selectedParents.includes(parent) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-purple-600 text-sm font-semibold",
                                                                    children: "Selected"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                    lineNumber: 1133,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                            lineNumber: 1105,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, parent, false, {
                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                        lineNumber: 1096,
                                                        columnNumber: 19
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 1094,
                                                columnNumber: 15
                                            }, this),
                                            selectedParents.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-4 p-3 bg-purple-50/50 rounded-lg border border-purple-200/50",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-sm text-purple-700",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "font-semibold",
                                                                children: selectedParents.length
                                                            }, void 0, false, {
                                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                lineNumber: 1146,
                                                                columnNumber: 21
                                                            }, this),
                                                            " ",
                                                            "parent block",
                                                            selectedParents.length > 1 ? "s" : "",
                                                            " ",
                                                            "selected:",
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "ml-2 font-medium",
                                                                children: selectedParents.join(", ")
                                                            }, void 0, false, {
                                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                lineNumber: 1151,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                        lineNumber: 1145,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs text-purple-600 mt-1",
                                                        children: selectedParents.length === 1 ? "Optimization will use this stock type" : "Optimization will consider multiple stock types"
                                                    }, void 0, false, {
                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                        lineNumber: 1155,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 1144,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                        lineNumber: 1059,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                lineNumber: 1053,
                                columnNumber: 11
                            }, this),
                            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-6 p-4 bg-red-50/80 border border-red-200/50 rounded-xl backdrop-blur-sm",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-red-600 font-medium flex items-center gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-4 h-4",
                                            fill: "currentColor",
                                            viewBox: "0 0 20 20",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                fillRule: "evenodd",
                                                d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z",
                                                clipRule: "evenodd"
                                            }, void 0, false, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 1174,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                            lineNumber: 1169,
                                            columnNumber: 17
                                        }, this),
                                        error
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                    lineNumber: 1168,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                lineNumber: 1167,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: onRun,
                                    disabled: running || blockData.length === 0 || selectedParents.length === 0,
                                    className: `px-12 py-4 rounded-xl text-white font-semibold text-lg shadow-2xl transform transition-all duration-300 hover:scale-105 active:scale-95 ${running || blockData.length === 0 || selectedParents.length === 0 ? "bg-gradient-to-r from-gray-400 to-gray-500 cursor-not-allowed" : "bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 shadow-blue-500/25"}`,
                                    children: running ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center justify-center gap-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"
                                            }, void 0, false, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 1204,
                                                columnNumber: 19
                                            }, this),
                                            "Processing Optimization..."
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                        lineNumber: 1203,
                                        columnNumber: 17
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center justify-center gap-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-5 h-5 text-white",
                                                fill: "none",
                                                stroke: "currentColor",
                                                viewBox: "0 0 24 24",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: 2,
                                                    d: "M13 10V3L4 14h7v7l9-11h-7z"
                                                }, void 0, false, {
                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                    lineNumber: 1215,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 1209,
                                                columnNumber: 19
                                            }, this),
                                            "Run Optimization"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                        lineNumber: 1208,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                    lineNumber: 1187,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                lineNumber: 1186,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                        lineNumber: 698,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-10",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-2xl font-bold text-gray-800 mb-6 flex items-center gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-2 h-8 bg-gradient-to-b from-green-500 to-teal-600 rounded-full"
                                    }, void 0, false, {
                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                        lineNumber: 1232,
                                        columnNumber: 13
                                    }, this),
                                    "Best Approaches"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                lineNumber: 1231,
                                columnNumber: 11
                            }, this),
                            approaches.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center py-12 bg-white/50 backdrop-blur-sm rounded-2xl border border-white/20 shadow-lg",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-16 h-16 bg-gradient-to-r from-gray-200 to-gray-300 rounded-full flex items-center justify-center mx-auto mb-4",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-8 h-8 text-gray-400",
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                                            }, void 0, false, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 1245,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                            lineNumber: 1239,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                        lineNumber: 1238,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-gray-500 text-lg",
                                        children: blockData.length === 0 ? "Import an Excel file and run optimization to see results." : "No results yet. Click Run to generate optimization approaches."
                                    }, void 0, false, {
                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                        lineNumber: 1253,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                lineNumber: 1237,
                                columnNumber: 13
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-1 lg:grid-cols-3 gap-6",
                                children: approaches.map((a, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        onClick: ()=>{
                                            if (a.visualizationFile) {
                                                // Clean the filename
                                                let cleanFilename = a.visualizationFile;
                                                if (cleanFilename.startsWith("visualizations/")) {
                                                    cleanFilename = cleanFilename.replace("visualizations/", "");
                                                }
                                                // Navigate to the visualization page
                                                window.open(`/visualization?file=${encodeURIComponent(cleanFilename)}`, "_blank");
                                            }
                                        },
                                        className: `bg-gradient-to-br ${a.color} p-6 rounded-2xl text-white shadow-2xl transform transition-all duration-300 hover:scale-105 ${a.visualizationFile ? "cursor-pointer" : ""}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex justify-between items-start mb-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                        className: "font-bold text-xl",
                                                        children: a.title
                                                    }, void 0, false, {
                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                        lineNumber: 1290,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "bg-white/20 px-3 py-1 rounded-full text-sm font-semibold backdrop-blur-sm",
                                                        children: [
                                                            "#",
                                                            idx + 1
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                        lineNumber: 1291,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 1289,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-white/90 mb-6 leading-relaxed",
                                                children: a.desc
                                            }, void 0, false, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 1295,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex justify-between items-center pt-4 border-t border-white/20",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-center",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "text-2xl font-bold",
                                                                children: a.efficiency
                                                            }, void 0, false, {
                                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                lineNumber: 1298,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "text-white/70 text-sm",
                                                                children: "Efficiency"
                                                            }, void 0, false, {
                                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                lineNumber: 1299,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                        lineNumber: 1297,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-center",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "text-2xl font-bold",
                                                                children: a.waste
                                                            }, void 0, false, {
                                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                lineNumber: 1302,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "text-white/70 text-sm",
                                                                children: "Waste"
                                                            }, void 0, false, {
                                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                lineNumber: 1303,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                        lineNumber: 1301,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 1296,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, idx, true, {
                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                        lineNumber: 1262,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                lineNumber: 1260,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                        lineNumber: 1230,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center text-gray-500 text-sm pt-8 border-t border-gray-200/50",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: "Daniel Corus Optimization System • Advanced Block Cutting Solutions"
                        }, void 0, false, {
                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                            lineNumber: 1314,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                        lineNumber: 1313,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                lineNumber: 599,
                columnNumber: 7
            }, this)
        }, void 0, false, {
            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
            lineNumber: 594,
            columnNumber: 5
        }, this);
    // ==========================
    // LOGIN OVERLAY COMPONENT
    // ==========================
    const renderLoginOverlay = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed inset-0 z-50 flex items-center justify-center p-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute inset-0 bg-black/20 backdrop-blur-md"
                }, void 0, false, {
                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                    lineNumber: 1328,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative bg-white/95 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/20 w-full max-w-md transform transition-all duration-500 scale-100",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-8 pb-0",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center justify-center gap-4 mb-8",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                            src: "/danieli_logo.svg",
                                            alt: "Danieli Corus Logo",
                                            className: "h-12 w-auto"
                                        }, void 0, false, {
                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                            lineNumber: 1335,
                                            columnNumber: 13
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                            className: "text-2xl font-bold text-gray-800 tracking-tight",
                                            children: [
                                                "DANIELI ",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-light",
                                                    children: "CORUS"
                                                }, void 0, false, {
                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                    lineNumber: 1341,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                            lineNumber: 1340,
                                            columnNumber: 13
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                    lineNumber: 1334,
                                    columnNumber: 11
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-center mb-8",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            className: "text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-3",
                                            children: "Welcome Back"
                                        }, void 0, false, {
                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                            lineNumber: 1346,
                                            columnNumber: 13
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-gray-600 text-lg",
                                            children: "Sign in to access the optimization system"
                                        }, void 0, false, {
                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                            lineNumber: 1349,
                                            columnNumber: 13
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                    lineNumber: 1345,
                                    columnNumber: 11
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                            lineNumber: 1333,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                            onSubmit: handleLogin,
                            className: "p-8 pt-6",
                            children: [
                                loginError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mb-6 p-4 bg-red-50/80 border border-red-200/50 rounded-xl backdrop-blur-sm",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-red-600 font-medium flex items-center gap-2 text-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-4 h-4 flex-shrink-0",
                                                fill: "currentColor",
                                                viewBox: "0 0 20 20",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    fillRule: "evenodd",
                                                    d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z",
                                                    clipRule: "evenodd"
                                                }, void 0, false, {
                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                    lineNumber: 1365,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 1360,
                                                columnNumber: 17
                                            }, this),
                                            loginError
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                        lineNumber: 1359,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                    lineNumber: 1358,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-6",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    htmlFor: "username",
                                                    className: "block text-sm font-semibold text-gray-700 mb-2",
                                                    children: "Username"
                                                }, void 0, false, {
                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                    lineNumber: 1379,
                                                    columnNumber: 15
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "relative",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                className: "h-5 w-5 text-gray-400",
                                                                fill: "none",
                                                                stroke: "currentColor",
                                                                viewBox: "0 0 24 24",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round",
                                                                    strokeWidth: 2,
                                                                    d: "M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                    lineNumber: 1393,
                                                                    columnNumber: 21
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                lineNumber: 1387,
                                                                columnNumber: 19
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                            lineNumber: 1386,
                                                            columnNumber: 17
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            id: "username",
                                                            type: "text",
                                                            value: username,
                                                            onChange: (e)=>setUsername(e.target.value),
                                                            className: "w-full pl-10 pr-4 py-4 border-2 border-gray-200/80 bg-white/50 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 backdrop-blur-sm font-medium text-gray-700 placeholder-gray-400",
                                                            placeholder: "Enter your username"
                                                        }, void 0, false, {
                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                            lineNumber: 1401,
                                                            columnNumber: 17
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                    lineNumber: 1385,
                                                    columnNumber: 15
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                            lineNumber: 1378,
                                            columnNumber: 13
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    htmlFor: "password",
                                                    className: "block text-sm font-semibold text-gray-700 mb-2",
                                                    children: "Password"
                                                }, void 0, false, {
                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                    lineNumber: 1414,
                                                    columnNumber: 15
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "relative",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                className: "h-5 w-5 text-gray-400",
                                                                fill: "none",
                                                                stroke: "currentColor",
                                                                viewBox: "0 0 24 24",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round",
                                                                    strokeWidth: 2,
                                                                    d: "M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                    lineNumber: 1428,
                                                                    columnNumber: 21
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                                lineNumber: 1422,
                                                                columnNumber: 19
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                            lineNumber: 1421,
                                                            columnNumber: 17
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            id: "password",
                                                            type: "password",
                                                            value: password,
                                                            onChange: (e)=>setPassword(e.target.value),
                                                            className: "w-full pl-10 pr-4 py-4 border-2 border-gray-200/80 bg-white/50 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 backdrop-blur-sm font-medium text-gray-700 placeholder-gray-400",
                                                            placeholder: "Enter your password"
                                                        }, void 0, false, {
                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                            lineNumber: 1436,
                                                            columnNumber: 17
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                    lineNumber: 1420,
                                                    columnNumber: 15
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                            lineNumber: 1413,
                                            columnNumber: 13
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "submit",
                                            disabled: loginLoading,
                                            className: `w-full px-8 py-4 text-white font-semibold text-lg rounded-xl shadow-2xl transform transition-all duration-300 hover:scale-105 active:scale-95 ${loginLoading ? "bg-gradient-to-r from-gray-400 to-gray-500 cursor-not-allowed" : "bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 shadow-blue-500/25"}`,
                                            children: loginLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-center gap-3",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"
                                                    }, void 0, false, {
                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                        lineNumber: 1459,
                                                        columnNumber: 19
                                                    }, this),
                                                    "Signing In..."
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 1458,
                                                columnNumber: 17
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-center gap-3",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        className: "w-5 h-5 text-white",
                                                        fill: "none",
                                                        stroke: "currentColor",
                                                        viewBox: "0 0 24 24",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round",
                                                            strokeWidth: 2,
                                                            d: "M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
                                                        }, void 0, false, {
                                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                            lineNumber: 1470,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                        lineNumber: 1464,
                                                        columnNumber: 19
                                                    }, this),
                                                    "Sign In to System"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                                lineNumber: 1463,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                            lineNumber: 1448,
                                            columnNumber: 13
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                    lineNumber: 1376,
                                    columnNumber: 11
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                            lineNumber: 1356,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-8 pt-6 border-t border-gray-100/50",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-center text-gray-500 text-sm",
                                children: "Secure access to Danieli Corus optimization platform"
                            }, void 0, false, {
                                fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                                lineNumber: 1486,
                                columnNumber: 11
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                            lineNumber: 1485,
                            columnNumber: 9
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
                    lineNumber: 1331,
                    columnNumber: 7
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/daniel-corus/Frontend/app/page.tsx",
            lineNumber: 1326,
            columnNumber: 5
        }, this);
    // ==========================
    // MAIN RENDER
    // ==========================
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$daniel$2d$corus$2f$Frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            renderMainInterface(),
            showLogin && renderLoginOverlay()
        ]
    }, void 0, true);
}
_s(Home, "eLsAUU4PAO77zyDS5fjZHhcNZ3k=");
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=daniel-corus_Frontend_eb471fc5._.js.map