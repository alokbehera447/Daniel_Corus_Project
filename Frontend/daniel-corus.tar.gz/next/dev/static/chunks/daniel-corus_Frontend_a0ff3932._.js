(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_c7bce699._.js",
  "static/chunks/fd557_next_dist_compiled_react-dom_ab31427f._.js",
  "static/chunks/fd557_next_dist_compiled_react-server-dom-turbopack_b7c5733d._.js",
  "static/chunks/fd557_next_dist_compiled_next-devtools_index_58106f7c.js",
  "static/chunks/fd557_next_dist_compiled_de8bc61b._.js",
  "static/chunks/fd557_next_dist_client_5f235470._.js",
  "static/chunks/fd557_next_dist_286c1b77._.js",
  "static/chunks/fd557_@swc_helpers_cjs_e199b1c5._.js"
],
    source: "entry"
});
