(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/daniel-corus_Frontend_eb471fc5._.js",
  "static/chunks/fd557_next_dist_compiled_react_064d8381._.js"
],
    source: "dynamic"
});
