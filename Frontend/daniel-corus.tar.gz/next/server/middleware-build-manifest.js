globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/6249bb6f9d2ce24c.js",
    "static/chunks/1acd2404566dad82.js",
    "static/chunks/c71e42cacbccb0ab.js",
    "static/chunks/1b3f57a1cd876719.js",
    "static/chunks/turbopack-014dfc0e4b99a4e5.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];