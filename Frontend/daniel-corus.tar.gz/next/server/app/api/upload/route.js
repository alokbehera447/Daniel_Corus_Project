var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/upload/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/fd557_next_dist_esm_build_templates_app-route_dc9477d0.js")
R.c("server/chunks/[root-of-the-server]__80c54af8._.js")
R.c("server/chunks/cdca0_Frontend__next-internal_server_app_api_upload_route_actions_fea9f349.js")
R.m(18737)
module.exports=R.m(18737).exports
