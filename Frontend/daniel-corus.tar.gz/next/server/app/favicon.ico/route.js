var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__80c54af8._.js")
R.c("server/chunks/fd557_next_dist_esm_build_templates_app-route_e9f78d00.js")
R.c("server/chunks/cdca0_Frontend__next-internal_server_app_favicon_ico_route_actions_efa080c3.js")
R.m(8654)
module.exports=R.m(8654).exports
