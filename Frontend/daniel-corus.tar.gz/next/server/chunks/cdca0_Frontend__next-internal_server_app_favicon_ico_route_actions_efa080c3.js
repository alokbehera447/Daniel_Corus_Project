module.exports=[89739,(e,o,d)=>{}];

//# sourceMappingURL=cdca0_Frontend__next-internal_server_app_favicon_ico_route_actions_efa080c3.js.map