module.exports=[59866,(a,b,c)=>{}];

//# sourceMappingURL=cdca0_Frontend__next-internal_server_app__global-error_page_actions_63668f9f.js.map