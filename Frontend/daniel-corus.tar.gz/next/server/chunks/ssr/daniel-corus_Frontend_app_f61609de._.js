module.exports=[75272,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},71531,a=>{"use strict";let b={src:a.i(75272).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=daniel-corus_Frontend_app_f61609de._.js.map