module.exports=[19857,(a,b,c)=>{}];

//# sourceMappingURL=daniel-corus_Frontend__next-internal_server_app__not-found_page_actions_5747dc7b.js.map