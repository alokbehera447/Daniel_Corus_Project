module.exports=[16437,(a,b,c)=>{}];

//# sourceMappingURL=daniel-corus_Frontend__next-internal_server_app_page_actions_85c2d67e.js.map